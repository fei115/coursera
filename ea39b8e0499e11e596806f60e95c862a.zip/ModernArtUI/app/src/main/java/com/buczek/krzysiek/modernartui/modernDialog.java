package com.buczek.krzysiek.modernartui;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.DialogFragment;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;

/**
 * Created by Krzysiek on 2015-08-23.
 */
public class modernDialog extends DialogFragment {


    private Button bVisitMoma;
    private Button bCancel;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.modern_dialog, container, false);




                // Set action to button visit MOMA
        bVisitMoma= (Button) v.findViewById(R.id.bVisitMoma);
        bVisitMoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent browseIntent = new Intent (Intent.ACTION_VIEW, Uri.parse("http://www.MoMA.org"));
                Intent chooserIntent = Intent.createChooser(browseIntent,"Load page: www.MoMa.org");
                startActivity(chooserIntent);
            }
        });
        //Set action to button Cancel
        bCancel = (Button) v.findViewById(R.id.bCancel);
        bCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            getDialog().dismiss();
            }
        });



        return v;

    }

    public void onResume()
    {
        super.onResume();

        Window window = getDialog().getWindow();
        //set Size
        int width = getResources().getDimensionPixelSize(R.dimen.modern_w);
        int height = getResources().getDimensionPixelSize(R.dimen.modern_h);
        window.setLayout(width, height);
        window.setGravity(Gravity.CENTER);

    }
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        final Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);



        return dialog;
    }

    static modernDialog newInstance(int num) {
        modernDialog f = new modernDialog();

        // Supply num input as an argument.
        Bundle args = new Bundle();
        args.putInt("num", num);
        f.setArguments(args);

        return f;
    }




}
