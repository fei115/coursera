package com.buczek.krzysiek.modernartui;

import android.app.DialogFragment;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.support.v4.app.FragmentManager;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import static android.graphics.Color.argb;

public class ModernartActivity extends AppCompatActivity {
    private SeekBar seekBar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modernart);
        seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBar.setMax(255);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                //Main layouyt color change - BLACK
                //RelativeLayout mainLayout = (RelativeLayout) findViewById(R.id.mainlayout);
                //mainLayout.setBackgroundColor(argb(255-progress,progress,progress,progress));
                //frame 1 - color change - BLUE
                FrameLayout frame1 = (FrameLayout) findViewById(R.id.frame1);
                frame1.setBackgroundColor(argb(255 , progress/10, progress, 255-progress) );
                //frame 2 - color change - GRAY
                FrameLayout frame2 = (FrameLayout) findViewById(R.id.frame2);
                frame2.setBackgroundColor(argb(255 - progress, 136, 136, 136));
                //frame 3 - color change - GREEN
                FrameLayout frame3 = (FrameLayout) findViewById(R.id.frame3);
                frame3.setBackgroundColor(-16711936 + progress);
                //frame 3 - color change - YELLOW
                FrameLayout frame4 = (FrameLayout) findViewById(R.id.frame4);
                frame4.setBackgroundColor(-256 + progress);
                //frame 3 - color change - RED
                FrameLayout frame5 = (FrameLayout) findViewById(R.id.frame5);
                frame5.setBackgroundColor(-65536 + progress);



            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_modernart, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.moreinformation) {
            FragmentManager fm = getSupportFragmentManager();
            modernDialog mD = new modernDialog();
            mD.show(fm, "dialog");

            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
