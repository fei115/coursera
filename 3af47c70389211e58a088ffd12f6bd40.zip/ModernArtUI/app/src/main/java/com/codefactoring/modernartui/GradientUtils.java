package com.codefactoring.modernartui;

import android.graphics.Color;

public class GradientUtils {

    public static final int MIN_RGB = 0;
    public static final int MAX_RGB = 255;

    public static int blendColors(float[] fractions, int[] colors, float progress) {
        final int color;

        if (fractions == null || colors == null) {
            throw new IllegalArgumentException("Fractions and colors must not be null");
        }

        if (fractions.length == colors.length) {

            final int[] indexes = getFractionIndexes(fractions, progress);

            final float[] range = new float[]{fractions[indexes[0]], fractions[indexes[1]]};
            final int[] colorRange = new int[]{colors[indexes[0]], colors[indexes[1]]};

            final float max = range[1] - range[0];
            final float value = progress - range[0];
            final float weight = value / max;

            color = blend(colorRange[0], colorRange[1], 1f - weight);
        } else {
            throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
        }
        return color;
    }

    private static int[] getFractionIndexes(float[] fractions, float progress) {
        int[] range = new int[2];

        int startPoint = MIN_RGB;
        while (startPoint < fractions.length && fractions[startPoint] <= progress) {
            startPoint++;
        }

        if (startPoint >= fractions.length) {
            startPoint = fractions.length - 1;
        }

        range[MIN_RGB] = startPoint - 1;
        range[1] = startPoint;

        return range;
    }

    private static int blend(int color1, int color2, double ratio) {
        final float r = (float) ratio;
        final float ir = (float) 1.0 - r;

        final int red = getRgbValue(Color.red(color1) * r + Color.red(color2) * ir);
        final int green = getRgbValue(Color.green(color1) * r + Color.green(color2) * ir);
        final int blue = getRgbValue(Color.blue(color1) * r + Color.blue(color1) * ir);

        return Color.rgb(red, green, blue);
    }

    private static int getRgbValue(float color) {
        if (color < MIN_RGB) {
            return MIN_RGB;
        } else if (color > MAX_RGB) {
            return MAX_RGB;
        } else {
            return (int) color;
        }
    }

    public static int[] convertToGradients(String[] colors) {
        return new int[]{Color.parseColor(colors[MIN_RGB]), Color.parseColor(colors[1]), Color.parseColor(colors[2])};
    }
}
