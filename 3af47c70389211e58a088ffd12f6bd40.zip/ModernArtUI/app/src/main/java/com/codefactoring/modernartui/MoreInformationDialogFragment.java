package com.codefactoring.modernartui;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class MoreInformationDialogFragment extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new AlertDialog.Builder(getActivity())
                .setMessage(R.string.moreInformation)
                .setCancelable(false)
                .setNegativeButton(R.string.notNow,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int id) {
                                dialog.dismiss();
                            }
                        })
                .setPositiveButton(R.string.moma,
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    final DialogInterface dialog, int id) {
                                final Intent intent = new Intent(Intent.ACTION_VIEW);
                                intent.setData(Uri.parse(getResources().getString(R.string.url)));
                                startActivity(intent);
                            }
                        }).create();
    }
}
