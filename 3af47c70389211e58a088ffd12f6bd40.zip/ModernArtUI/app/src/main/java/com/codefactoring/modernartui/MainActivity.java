package com.codefactoring.modernartui;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SeekBar;


public class MainActivity extends ActionBarActivity {

    private static final float[] fractions = new float[]{0f, 0.5f, 1f};

    private static final String[][] colors = new String[][]{
            {"#FF001C", "#FF6675", "#FFCCD1"}, // Red gradient
            {"#003CFF", "#668AFF", "#CCD8FF"}, // Blue gradient
            {"#00FF02", "#66FF67", "#CCFFCC"}, // Green gradient
            {"#FFF800", "#FFFA66", "#FFFDCC"}  // Yellow gradient
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initColors();

        final SeekBar seekBar = (SeekBar) findViewById(R.id.SeekBar);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    final float progressFraction = progress / 100f;
                    findViewById(R.id.red).setBackgroundColor(GradientUtils.blendColors(fractions,
                            GradientUtils.convertToGradients(colors[0]), progressFraction));
                    findViewById(R.id.blue).setBackgroundColor(GradientUtils.blendColors(fractions,
                            GradientUtils.convertToGradients(colors[1]), progressFraction));
                    findViewById(R.id.green).setBackgroundColor(GradientUtils.blendColors(fractions,
                            GradientUtils.convertToGradients(colors[2]), progressFraction));
                    findViewById(R.id.yellow).setBackgroundColor(GradientUtils.blendColors(fractions,
                            GradientUtils.convertToGradients(colors[3]), progressFraction));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // do nothing
            }
        });
    }

    private void initColors() {
        findViewById(R.id.red).setBackgroundColor(Color.parseColor(colors[0][0]));
        findViewById(R.id.blue).setBackgroundColor(Color.parseColor(colors[1][0]));
        findViewById(R.id.green).setBackgroundColor(Color.parseColor(colors[2][0]));
        findViewById(R.id.yellow).setBackgroundColor(Color.parseColor(colors[3][0]));
        findViewById(R.id.white).setBackgroundColor(Color.WHITE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (R.id.info == item.getItemId()) {
            new MoreInformationDialogFragment().show(getFragmentManager(), "");
        }
        return super.onOptionsItemSelected(item);

    }
}
