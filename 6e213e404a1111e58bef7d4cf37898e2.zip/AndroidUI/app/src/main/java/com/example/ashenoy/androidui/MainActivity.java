package com.example.ashenoy.androidui;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.SeekBar;


public class MainActivity extends ActionBarActivity {

    private static final int transparency_offset = 150;
    private DialogFragment dialogFrag = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button1 = (Button)findViewById(R.id.button);
        final Button button2 = (Button)findViewById(R.id.button2);
        final Button button3 = (Button)findViewById(R.id.button3);
        final Button button4 = (Button)findViewById(R.id.button4);
        final Button button5 = (Button)findViewById(R.id.button5);

        final SeekBar seekBar = (SeekBar)findViewById(R.id.seekBar);
        seekBar.setMax(100);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                button1.getBackground().setAlpha(progress + transparency_offset);
                button2.getBackground().setAlpha(progress + transparency_offset);
                button3.getBackground().setAlpha(progress + transparency_offset);
                button4.getBackground().setAlpha(progress + transparency_offset);
                button5.getBackground().setAlpha(progress + transparency_offset);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            showDialogFragment();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    void showDialogFragment(){
        dialogFrag = WebDialogFragment.newInstance();
        dialogFrag.show(getFragmentManager(), "Alert");
    }

    public void openMOMA(){
        Uri webpage = Uri.parse("http://www.moma.org");
        Intent momaIntent = new Intent(Intent.ACTION_VIEW, webpage);
        if(momaIntent.resolveActivity(getPackageManager()) != null){
            startActivity(momaIntent);
        }

    }

    public static class WebDialogFragment extends DialogFragment{

        public static WebDialogFragment newInstance() {
            return new WebDialogFragment();
        }

        @Override
        public Dialog onCreateDialog(Bundle saveInstanceState){
            return new AlertDialog.Builder(getActivity())
                                        .setMessage("Do you want more information?")
                                        .setCancelable(false)
                                        .setNegativeButton("Not now",
                                                new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        ((AlertDialog)dialog).dismiss();
                                                    }
                                                })
                                        .setPositiveButton("Visit MOMA",
                                                new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        ((MainActivity)getActivity()).openMOMA();
                                                    }
                                                }).create();



        }


    }






}
